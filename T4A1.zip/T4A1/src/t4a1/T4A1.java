package t4a1;

import java.util.Scanner;

public class T4A1 {

    public static void main(String[] args) {
        //ejer1();
        ejer2();
    }
    public static void menu(){
        
    }
    public static void ejer1(){
        Scanner sc = new Scanner(System.in);
        
        int numero = 0;
        System.out.println("Hasta Donde Quieres Llegar: ");
        int limite = sc.nextInt();
  
        while(numero<limite){
            numero++;
            System.out.println(numero);
        }
    }
    public static void ejer2(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Piezas a Confeccionar: ");
        int np = sc.nextInt();
        int n  = 0;
        int tallaS = 0, tallaM = 0, tallaL = 0, tallaXL = 0;
        
        while(n<np){
            n++;
            System.out.println("\n Talla: ");
            String talla = sc.next();
            
            if(talla.equals("S")|| talla.equals("s")){
            tallaS++;
            }else if(talla.equals("M")|| talla.equals("m")){
            tallaM++;
            }else if(talla.equals("L")|| talla.equals("l")){
            tallaL++;
            }else{
            tallaXL++;
            }
            }
            System.out.println("Cantidades por Talla: \n" 
                    + "chica (S)\t\t" + tallaS + "\n"
                    + "Mediana (M)\t\t" + tallaM + "\n"
                    + "Grande (L)\t\t"+ tallaL+"\n"
                    + "Extra Grande(XL)\t"+ tallaXL);       
    }
    
    public static void ejer3(){
    Scanner obj = new Scanner(System.in);
    
        System.out.print("Ingrese el Numero de Estudiantes: ");
        int e=obj.nextInt();
        int j=1;
        int a=0, r=0, i=0;
        System.out.println("\nIngrese las Calificaciones en Escala de 0 a 100");
        while(j<=e){
            System.out.print("Calificacion del Estudiante " + j + ": ");
            int c=obj.nextInt();
            if(c>=70 && c<101){
                a++;
            }else if(c>=0 && c<70){
            r++;
            }else{
            i++;
            }
            j++;
        }
        System.out.println("\nEl numero de estudiantes con calificacion mayor o igual a 70 es: " + a +
                "\nEl numero de estudiantes con calificacion menor a 70 es: " + r +
                "\nCalificaciones invalidas: " + i );
    }
    
    public static void ejer4(){
     Scanner obj = new Scanner(System.in);
     
        System.out.print("Ingrese un numero: ");
        int n=obj.nextInt();
        System.out.print("Ingrese el numero limite: ");
        int l=obj.nextInt();
        int j=n;
        while(j<=l){
            System.out.println("Multiplo: " + j);
        j=j+n;           
        }
    }
}